#ifndef WPROGRAM_H__
#define WPROGRAM_H__

#include "Stream.h"
#include "Utils.h"
#include "Wire.h"
#include "Print.h"
#include "Common.h"

#endif //WPROGRAM_H__
