# CPP-H264-Encoder
External dependency for encoding opencv frames in h264.

This is adapted from https://github.com/cbachhuber/CppVideoStreamer with changes to the CMakeLists to allow for installation.
